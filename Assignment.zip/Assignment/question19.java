public class HelloWorld
{
  public static void main(String[] args)
  {
      //System.out.println("Enter the number of items");
    int number=5;
      int maxLimit=number*3;
    for( int i=1;i<=maxLimit;)
    {
           
            System.out.println(i);
             i=i+3;
       
    }
		
  }
}
