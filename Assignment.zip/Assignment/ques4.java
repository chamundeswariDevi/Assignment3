public class HelloWorld
{
  public static void main(String[] args)
  {
      //System.out.println("Enter the number of items");
      
    for(int i=1;i<=8;i++)
    {
        for(int j=2*(8-i);j>=0;j--)
        {
             System.out.print(" ");
        }
           for(int j=1;j<=i;j++)
           {
                System.out.print("* ");
           }
            System.out.println(" ");
             
       
    }
		
  }
}
