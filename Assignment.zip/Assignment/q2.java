public static void main(String[] args) {
		for(int i=1;i<=8;i++)
		{
		    for(int j=0;j<=8;j++)
		    {
		        System.out.print(i);
		    }
		
		    System.out.println();		
		    
		}
}
}