public class HelloWorld
{
  public static void main(String[] args)
  {
      //System.out.println("Enter the number of items");
    for( int i=1;i<=5;i++)
    {
           
            System.out.print(i+ " ");
             
       
    }
		
  }
}